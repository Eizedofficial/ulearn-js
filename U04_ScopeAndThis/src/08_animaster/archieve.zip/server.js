const express = require('express')
const path = require('path')

const __dirName = path.resolve()

const app = express()
const port = process.env.PORT ?? 1111

app.use(express.static(path.resolve(__dirName,'.')))

app.listen(port,()=>{
    console.log(`Server has benn started on http://localhost:${port}`)
})
